// server.js

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

// Initialize Express app
const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/alertDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB connected'))
.catch(err => console.error('❌ MongoDB connection error:', err));

// Define a Schema and Model
const alertSchema = new mongoose.Schema({
  gesture: String,
  faceDetected: Boolean,
  timestamp: { type: Date, default: Date.now },
});

const Alert = mongoose.model('Alert', alertSchema);

// Root route
app.get('/', (req, res) => {
  res.send('👋 Welcome to the Emergency Alert Server');
});

// POST route to receive alert
app.post('/send-alert', async (req, res) => {
  const { gesture, faceDetected } = req.body;

  if (!gesture) {
    return res.status(400).json({ message: '❌ Gesture is required' });
  }

  try {
    const alert = new Alert({ gesture, faceDetected });
    await alert.save();

    console.log(`🚨 Alert saved: ${gesture}, Face Detected: ${faceDetected}`);
    res.status(200).json({ message: '✅ Alert received and saved successfully' });
  } catch (error) {
    console.error('❌ Error saving alert:', error);
    res.status(500).json({ message: '❌ Server error' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
