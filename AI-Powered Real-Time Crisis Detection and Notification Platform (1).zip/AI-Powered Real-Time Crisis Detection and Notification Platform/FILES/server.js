// server.js
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

// Connect to MongoDB — update your connection string if needed
mongoose.connect('mongodb://localhost:27017/emergencyDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log("MongoDB connected"))
.catch(err => console.error("MongoDB connection error:", err));

const EmergencySchema = new mongoose.Schema({
  keyword: String,
  transcript: String,
  latitude: Number,
  longitude: Number,
  address: String,
  timestamp: { type: Date, default: Date.now }
});

const Emergency = mongoose.model('Emergency', EmergencySchema);

const app = express();
app.use(cors());
app.use(express.json());

app.post('/api/emergency', async (req, res) => {
  try {
    const { keyword, transcript, latitude, longitude, address } = req.body;
    const newRecord = new Emergency({ keyword, transcript, latitude, longitude, address });
    await newRecord.save();
    res.status(201).json({ message: "Emergency recorded successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
