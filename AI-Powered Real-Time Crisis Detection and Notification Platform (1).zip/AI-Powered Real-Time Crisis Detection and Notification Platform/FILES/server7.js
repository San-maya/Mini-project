// Install dependencies: npm install express @google-cloud/vision body-parser cors

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const vision = require('@google-cloud/vision');

const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: '10mb' }));

// Google Vision client
const client = new vision.ImageAnnotatorClient({
  keyFilename: __dirname + '/vision-key.json' // path to your JSON key
});

// Endpoint to detect faces from base64 image
app.post('/detect-faces', async (req, res) => {
  try {
    const imageBase64 = req.body.image.replace(/^data:image\/\w+;base64,/, '');
    const buffer = Buffer.from(imageBase64, 'base64');

    const [result] = await client.faceDetection({ image: { content: buffer } });
    const faces = result.faceAnnotations;

    res.json({ faces });
  } catch (error) {
    console.error('Error detecting faces:', error);
    res.status(500).json({ error: 'Face detection failed' });
  }
});

app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
