const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

// Initialize app
const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/crisis_platform', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('✅ MongoDB connected...'))
.catch(err => console.error('❌ MongoDB connection error:', err));

// Schema
const emergencyContactSchema = new mongoose.Schema({
  name: String,
  phone: String,
  relation: String
});

const userSchema = new mongoose.Schema({
  fullName: String,
  email: String,
  phone: String,
  password: String,
  medicalInfo: String,
  emergencyContacts: [emergencyContactSchema]
});

const User = mongoose.model('User', userSchema);

// POST route for /register
app.post('/register', async (req, res) => {
  try {
    const {
      fullName, email, phone, password, medicalInfo,
      emergencyName = [], emergencyPhone = [], emergencyRelation = []
    } = req.body;

    // Combine contact info into objects
    const emergencyContacts = emergencyName.map((name, index) => ({
      name,
      phone: emergencyPhone[index],
      relation: emergencyRelation[index]
    }));

    const newUser = new User({
      fullName,
      email,
      phone,
      password,
      medicalInfo,
      emergencyContacts
    });

    await newUser.save();
    res.status(201).json({ message: 'User registered successfully!' });
  } catch (error) {
    console.error('Error saving user:', error);
    res.status(500).json({ message: 'Registration failed' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
