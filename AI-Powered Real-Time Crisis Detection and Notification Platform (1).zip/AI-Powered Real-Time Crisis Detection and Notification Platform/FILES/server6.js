const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

// Replace with your Twilio credentials
const accountSid = 'YOUR_TWILIO_ACCOUNT_SID';
const authToken = 'YOUR_TWILIO_AUTH_TOKEN';
const client = require('twilio')(accountSid, authToken);

app.use(cors());
app.use(express.json());

app.post('/send-sms', (req, res) => {
  const { to, message } = req.body;
  if (!to || !message) {
    return res.status(400).json({ error: 'Missing to or message' });
  }

  client.messages
    .create({
      body: message,
      from: '+YOUR_TWILIO_PHONE_NUMBER', // your Twilio phone number
      to: to
    })
    .then(message => res.json({ sid: message.sid }))
    .catch(err => {
      console.error(err);
      res.status(500).json({ error: 'Failed to send SMS' });
    });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
